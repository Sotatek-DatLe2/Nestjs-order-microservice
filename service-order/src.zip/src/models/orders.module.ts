import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrderService } from './Order/order.service';
import { OrderController } from '../controller/order.controller';
import { OrderRepository } from './Order/order.repository';
import { Order } from './Order/order.entity';
import { OrderHistory } from './OrderHistory/orderHistory.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Order, OrderHistory])],
  providers: [OrderService, OrderRepository],
  controllers: [OrderController],
})
export class OrdersModule {}