import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DeepPartial } from 'typeorm';
import { plainToClass } from 'class-transformer';
import { Order } from './order.entity';
import { OrderHistory } from '../OrderHistory/orderHistory.entity';
import { OrderSerializer } from './order.serializer';
import { OrderStatus } from '../../common/order.enum';
import { OrderFSM } from './order.sm';

@Injectable()
export class OrderRepository {
  constructor(
    @InjectRepository(Order)
    private readonly orderRepository: Repository<Order>,
    @InjectRepository(OrderHistory)
    private readonly historyRepository: Repository<OrderHistory>,
  ) {}

  /**
   * Retrieves all orders with optional query options.
   * @param options TypeORM query options (e.g., relations, where).
   * @returns Array of serialized orders.
   */
  async findAll(options: any = {}): Promise<OrderSerializer[]> {
    const orders = await this.orderRepository.find({
      ...options,
      relations: options.relations ?? ['history'],
    });
    return this.transformMany(orders);
  }

  /**
   * Retrieves a single order by ID.
   * @param id Order ID.
   * @param relations Relations to load (defaults to ['history']).
   * @returns Serialized order or throws NotFoundException.
   */
  async get(id: string, relations: string[] = ['history']): Promise<OrderSerializer> {
    const order = await this.orderRepository.findOne({ where: { id }, relations });
    if (!order) {
      throw new NotFoundException(`Order with ID ${id} not found.`);
    }
    return this.transform(order);
  }

  /**
   * Creates a new order and its initial history entry.
   * @param inputs Order data.
   * @returns Serialized order.
   */
  async createEntity(inputs: DeepPartial<Order>): Promise<OrderSerializer> {
    const order = this.orderRepository.create(inputs);
    const savedOrder = await this.orderRepository.save(order);

    await this.createHistoryEntry(savedOrder, OrderStatus.CREATED);

    return this.transform(savedOrder);
  }

  /**
   * Updates the status of an order with state machine validation.
   * @param id Order ID.
   * @param newStatus New status to transition to.
   * @returns Serialized order.
   */
  async updateStatus(id: string, newStatus: OrderStatus): Promise<OrderSerializer> {
    const order = await this.orderRepository.findOne({ where: { id }, relations: ['history'] });
    if (!order) {
      throw new NotFoundException(`Order with ID ${id} not found.`);
    }

    const currentStatus = this.getLatestStatus(order);
    this.validateStatusTransition(currentStatus, newStatus);

    await this.createHistoryEntry(order, newStatus);

    // Reload order to include updated history
    return this.get(id);
  }

  /**
   * Creates a history entry for an order.
   * @param order Order entity.
   * @param status Status to record.
   */
  private async createHistoryEntry(order: Order, status: OrderStatus): Promise<void> {
    const history = this.historyRepository.create({
      status,
      order,
    });
    await this.historyRepository.save(history);
  }

  /**
   * Gets the latest status from order history.
   * @param order Order entity with history.
   * @returns Latest status.
   */
  private getLatestStatus(order: Order): OrderStatus {
    if (!order.history || order.history.length === 0) {
      throw new Error('Order has no history entries.');
    }
    return order.history.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())[0].status;
  }

  /**
   * Validates status transition using OrderFSM.
   * @param currentStatus Current status.
   * @param newStatus Desired status.
   * @throws Error if transition is invalid.
   */
  private validateStatusTransition(currentStatus: OrderStatus, newStatus: OrderStatus): void {
    const fsm = new OrderFSM(currentStatus);
    fsm.transition(newStatus);
  }

  /**
   * Transforms an Order entity to OrderSerializer.
   * @param model Order entity.
   * @param transformOptions Class-transformer options.
   * @returns Serialized order.
   */
  private transform(model: Order, transformOptions: any = {}): OrderSerializer {
    return plainToClass(OrderSerializer, model, transformOptions);
  }

  /**
   * Transforms multiple Order entities to OrderSerializer array.
   * @param models Array of Order entities.
   * @param transformOptions Class-transformer options.
   * @returns Array of serialized orders.
   */
  private transformMany(models: Order[], transformOptions: any = {}): OrderSerializer[] {
    return models.map((model) => this.transform(model, transformOptions));
  }
}