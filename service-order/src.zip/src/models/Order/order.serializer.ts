import { Expose, Type } from 'class-transformer';
import { IsString, IsNumber, IsDate, IsNotEmpty, IsArray, IsEnum } from 'class-validator';
import { z } from 'zod';
import { OrderStatus } from '../../common/order.enum';

// Zod schema for OrderHistorySerializer
export const OrderHistorySerializerSchema = z.object({
  id: z.string().uuid(),
  status: z.enum([OrderStatus.CREATED, OrderStatus.CONFIRMED, OrderStatus.CANCELLED, OrderStatus.DELIVERED]),
  createdAt: z.date(),
});

// Zod schema for OrderSerializer
export const OrderSerializerSchema = z.object({
  id: z.string().uuid(),
  customerName: z.string().min(1, 'Customer name is required'),
  description: z.string().optional(),
  totalAmount: z.number().positive('Total amount must be positive'),
  createdAt: z.date(),
  updatedAt: z.date(),
  history: z.array(OrderHistorySerializerSchema).optional(),
});

// Type for OrderSerializer
export type OrderSerializerType = z.infer<typeof OrderSerializerSchema>;

// OrderHistorySerializer class
export class OrderHistorySerializer {
  @Expose()
  @IsString()
  @IsNotEmpty()
  id: string;

  @Expose()
  @IsEnum(OrderStatus)
  @IsNotEmpty()
  status: OrderStatus;

  @Expose()
  @Type(() => Date)
  @IsDate()
  @IsNotEmpty()
  createdAt: Date;
}

// OrderSerializer class
export class OrderSerializer {
  @Expose()
  @IsString()
  @IsNotEmpty()
  id: string;

  @Expose()
  @IsString()
  @IsNotEmpty()
  customerName: string;

  @Expose()
  @IsString()
  description: string;

  @Expose()
  @IsNumber()
  @IsNotEmpty()
  totalAmount: number;

  @Expose()
  @Type(() => Date)
  @IsDate()
  @IsNotEmpty()
  createdAt: Date;

  @Expose()
  @Type(() => Date)
  @IsDate()
  @IsNotEmpty()
  updatedAt: Date;

  @Expose()
  @Type(() => OrderHistorySerializer)
  @IsArray()
  history: OrderHistorySerializer[];
}