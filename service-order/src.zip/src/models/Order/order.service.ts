import { Injectable, BadRequestException } from '@nestjs/common';
import { OrderRepository } from './order.repository';
import { CreateOrderDto, UpdateOrderStatusDto, CreateOrderSchema, UpdateOrderStatusSchema } from '../Order/order.dto';
import { OrderSerializer } from './order.serializer';

@Injectable()
export class OrderService {
  constructor(private readonly orderRepository: OrderRepository) {}

  async createOrder(dto: CreateOrderDto): Promise<OrderSerializer> {
    const parsed = CreateOrderSchema.safeParse(dto);
    if (!parsed.success) {
      throw new BadRequestException(parsed.error.errors);
    }
    return this.orderRepository.createEntity(parsed.data);
  }

  async getOrder(id: string): Promise<OrderSerializer> {
    const order = await this.orderRepository.get(id);
    if (!order) {
      throw new BadRequestException(`Order with id ${id} not found`);
    }
    return order;
  }

  async updateOrderStatus(id: string, dto: UpdateOrderStatusDto): Promise<OrderSerializer> {
    const parsed = UpdateOrderStatusSchema.safeParse(dto);
    if (!parsed.success) {
      throw new BadRequestException(parsed.error.errors);
    }
    return this.orderRepository.updateStatus(id, parsed.data.status);
  }

  async findAllOrders(): Promise<OrderSerializer[]> {
    return this.orderRepository.findAll();
  }
}