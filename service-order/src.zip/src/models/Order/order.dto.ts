import { z } from 'zod';
import { OrderStatus } from '../../common/order.enum';

// Schema cho tạo đơn hàng
export const CreateOrderSchema = z.object({
  customerName: z.string().min(1, 'Customer name is required'),
  description: z.string().optional(),
  totalAmount: z.number().positive('Total amount must be positive'),
});

// Schema cho cập nhật trạng thái
export const UpdateOrderStatusSchema = z.object({
  status: z.enum([OrderStatus.CREATED, OrderStatus.CONFIRMED, OrderStatus.CANCELLED, OrderStatus.DELIVERED]),
});

// Types được suy ra từ schema
export type CreateOrderDto = z.infer<typeof CreateOrderSchema>;
export type UpdateOrderStatusDto = z.infer<typeof UpdateOrderStatusSchema>;