import { Controller, Get, Post, Patch, Param, Body, HttpCode } from '@nestjs/common';
  import { OrderService } from '../models/Order/order.service';
  import { CreateOrderDto, UpdateOrderStatusDto } from '../models/Order/order.dto';
  import { OrderSerializer } from '../models/Order/order.serializer';

  @Controller('orders')
  export class OrderController {
    constructor(private readonly orderService: OrderService) {}

    @Post()
    async create(@Body() createOrderDto: CreateOrderDto): Promise<OrderSerializer> {
      return this.orderService.createOrder(createOrderDto);
    }

    @Get(':id')
    async findOne(@Param('id') id: string): Promise<OrderSerializer> {
      return this.orderService.getOrder(id);
    }

    @Get()
    async findAll(): Promise<OrderSerializer[]> {
      return this.orderService.findAllOrders();
    }

    @Patch(':id/status')
    @HttpCode(200)
    async updateStatus(
      @Param('id') id: string,
      @Body() updateStatusDto: UpdateOrderStatusDto,
    ): Promise<OrderSerializer> {
      return this.orderService.updateOrderStatus(id, updateStatusDto);
    }
  }